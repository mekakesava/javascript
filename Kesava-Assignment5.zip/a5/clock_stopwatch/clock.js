"use strict";
var $ = function(id) { return document.getElementById(id); };

//global stop watch timer variable and elapsed time object
var stopwatchTimer;
var elapsedMinutes = 0;
var elapsedSeconds = 0;
var elapsedMilliseconds = 0;

var displayCurrentTime = function() {
	
let hrs, mins, secs;
   let current_date = new Date();
   hrs = padSingleDigit(current_date.getHours());
   mins = padSingleDigit(current_date.getMinutes());
   secs = padSingleDigit(current_date.getSeconds());
   if (hrs > 12) {
       hrs = padSingleDigit(hrs - 12);
       $("ampm").innerHTML = "PM"
   }
   else {
       $("ampm").innerHTML = "AM"
   }

   $("hours").innerHTML = hrs;
   $("minutes").innerHTML = mins;
   $("seconds").innerHTML = secs;
  

};

    	//create a date object and find out if it is AM or PM
	//display the hours, minutes, milliseconds and AM/PM on the webpage

var padSingleDigit = function(num) {
	if (num < 10) {	return "0" + num; }
	else { return num; }
};

var tickStopwatch = function() {
    // increment milliseconds by 10 milliseconds
    elapsedMilliseconds += 10;
    // if milliseconds total 1000, increment seconds by one and reset milliseconds to zero
    if (elapsedMilliseconds >= 1000) {
        elapsedSeconds += 1;
        elapsedMilliseconds = 0;
    }
    // if seconds total 60, increment minutes by one and reset seconds to zero
    if (elapsedSeconds >= 60) {
        elapsedMinutes += 1;
        elapsedSeconds = 0;
    }
    //display new stopwatch time
    $("s_ms").innerHTML = elapsedMilliseconds;
    $("s_seconds").innerHTML = elapsedSeconds;
    $("s_minutes").innerHTML = elapsedMinutes;
};

var startStopwatch = function(evt) {
    // prevent default action of link
    if (!evt) { evt = window.event; }
    if (evt.preventDefault) { evt.preventDefault(); }
    else { evt.returnFalse = false; }
    // do first tick of stop watch and then set interval timer to tick
    setInterval(tickStopwatch, 10);
    stopwatchTimer = setInterval(tickStopwatch, 10);
    // ??? stop watch every 10 milliseconds. Store timer object in stopwatchTimer 
    // ??? variable so next two functions can stop timer.
};

var stopStopwatch = function(evt) {
    if (!evt) { evt = window.event; }
    if (evt.preventDefault) { evt.preventDefault(); }
    else { evt.returnFalse = false; }
    // prevent default action of link
    clearInterval(stopwatchTimer);
    // stop timer
};

var resetStopwatch = function(evt) {
    // prevent default action of link
    if (!evt) { evt = window.event; }
    if (evt.preventDefault) { evt.preventDefault(); }
    else { evt.returnFalse = false; }
    // stop timer
    clearInterval(stopwatchTimer);
    // reset elapsed variables and clear stopwatch display
    $("s_ms").innerHTML = "000";
    $("s_seconds").innerHTML = "00";
    $("s_minutes").innerHTML = "00";
    elapsedMilliseconds = 0;
    elapsedMinutes = 0;
    elapsedSeconds = 0;

    
};

window.onload = function() {
    // set initial clock display and then set interval timer to display new time every second.
    displayCurrentTime();
    setInterval(displayCurrentTime, 1000);
    // set up stopwatch event handlers
    $("start").onclick = startStopwatch
    $("stop").onclick = stopStopwatch
    $("reset").onclick = resetStopwatch
};