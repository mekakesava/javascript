"use strict";
var $ = function(id) { return document.getElementById(id); };

var displayCurrentTime = function() {
   let hh, mm, ss;
   let current_date = new Date();
   hh = padSingleDigit(current_date.getHours());
   mm = padSingleDigit(current_date.getMinutes());
   ss = padSingleDigit(current_date.getSeconds());
   if (hh > 12) {
       hh = padSingleDigit(hh - 12);
       $("ampm").innerHTML = "PM"
   }
   else {
       $("ampm").innerHTML = "AM"
   }

   $("hours").innerHTML = hh;
   $("minutes").innerHTML = mm;
   $("seconds").innerHTML = ss;
  

};

var padSingleDigit = function(num) {
	if (num < 10) {	return "0" + num; }
	else { return num; }
};

window.onload = function() {
    displayCurrentTime();
    setInterval(displayCurrentTime, 1000);
    // set initial clock display and then set interval timer to display
    // new time every second. Don't store timer object because it 
    // won't be needed - clock will just run.
};