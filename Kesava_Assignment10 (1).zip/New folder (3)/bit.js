


document.addEventListener('DOMContentLoaded',function(){
	fetchData();
	setInterval(fetchData, 15000);
	});
	 const fetchData = function(){
		 fetch('https://api.coindesk.com/v1/bpi/currentprice.json')
		 .then(response => response.json())
		 .then(renderData);
	 }
	
	 const renderData = function(data) {
		 const PriceUSD = document.querySelector(".usd");
		 PriceUSD.innerHTML = data.bpi.USD.rate;
	
		 const PriceEUR = document.querySelector(".eur");
		 PriceEUR.innerHTML = data.bpi.EUR.rate;
	
		 const PriceGBP = document.querySelector(".gbp");
		 PriceGBP.innerHTML = data.bpi.GBP.rate;
	
		
	 }