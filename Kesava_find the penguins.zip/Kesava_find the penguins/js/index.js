let score = 0;
let game,penguins,yeti;

$(document).ready( function() {

    yeti = document.querySelector("#yeti");
    penguins = document.querySelectorAll(".penguin");
    highscore = document.querySelector("#highscore");
    penguins.forEach(function(penguin)
    {    
        penguin.onclick = penguinclick;
    });
        yeti.onclick = yeticlick;
});
        const penguinclick = function(){
            var audio = new Audio("penguinsound.mp3");
            audio.play();
            if(!this.classList.contains('up'))
            {  
                this.classList.add('up'); 
                score+=1;
                document.querySelector("#currentscore").innerHTML = score;
                var ele = this.id;
                document.getElementById(this.id).style.backgroundImage="url('./images/"+ele+".png')";
            }
        }

        const yeticlick = function(){
        
            
            endgame();
            var yetiaudio = new Audio("yetisound.mp3");
            yetiaudio.play();
        }
        const endgame = function(){
            alert('Game over '+"\n"+'your score is: '+document.querySelector("#currentscore").innerHTML);
            score = 0;
            document.querySelector("#currentscore").innerHTML=score;
            location.reload();
                 
        }
        const resetgame = function(){

            const yetiindex = Math.round(Math.random()*(penguins.length-1));
            document.querySelector("#gameholder").insertBefore(yeti,document.querySelector("#gameholder").children[yetiindex]);
            score=0;
            document.querySelector("#currentscore").innerHTML=score;
        }
 window.onload = resetgame;

    












