
// Usage of date object of 5%


var today = new Date();

var date = today.getDate();
var month = today.getMonth() + 1;
var year = today.getFullYear();
if (date < 10) {
  date = '0' + date;
}

if (month < 10) {
  month = '0' + month;
} 
today = date + '-' + month + '-' + year;
document.getElementById('date').innerHTML = today;




const getBtn = document.getElementById('get-btn');
const postBtn = document.getElementById('post-btn');

// object constructors with parameter of 5%
const sendRequest = function(method, link, data)  {
  //c Usage of xmlhttp requests and responses to get xml/json data of 15%+15%
  const promise = new Promise(function(resolve)  {
    const request = new XMLHttpRequest();
     request.open(method, link);
    request.responseType = 'json';
    request.setRequestHeader('Content-Type', 'application/json');
    request.onload = function()  {

      resolve(request.response);
    }
    request.send(JSON.stringify(data));
  });
  return promise;
};
// Usage of 3rd party api of 10%
const getData = function() {
  sendRequest('GET', 'https://reqres.in/api/users').then(function(responseData) {

    document.getElementById('xmldata').innerHTML = 'Data Received..... Check in console';
     console.log(responseData);
  });
};

const senddata = function() {
  sendRequest('POST', 'https://reqres.in/api/register', {
    email: 'eve.holt@reqres.in',
    password: 'pistol'
  })
    .then(function(responseData)  {
      console.log(responseData);
      document.getElementById('xmldata').innerHTML = 'Data Sent.... Check in console';
    })

};

getBtn.addEventListener('click', getData);
postBtn.addEventListener('click', senddata);
