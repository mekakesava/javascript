
// professorsList is an array of objects of 5%

const nextButton = document.getElementById('next');
nextButton.addEventListener('click', nextProfessor);

function Professors(professorsList) 
{
    let index= 0;
    return {
// Usage of ternary operator
      next() 
      {
            return index< professorsList.length ?

                { 
                    value: professorsList[index++], done: false 
                } :

                { done: true }
        }
    };
}

const professorsList = [
    {
        name: 'Hulk',
        age: 40,
        city: 'Kolkata',
        language: 'Python',
        framework: 'Vs',
        image: 'images/1.jfif'
    },

    {
        name: 'Spider',
        age: 28,
        city: 'Bangalore',
        language: 'JavaScript',
        framework: 'Angular',
        image: 'images/2.jfif'
    },

    {
        name: 'Captain America',
        age: 50,
        city: 'Kolkata',
        language: 'Python',
        framework: 'Adobe',
        image: 'images/3.jfif'
    },

    {
        name: 'Halwa Raj',
        age: 45,
        city: 'Mumbai',
        language: 'Python',
        framework: 'Flask',
        image: 'images/4.jfif'
    },

    {
        name: 'Stan Lee',
        age: 66,
        city: 'Jharkhand',
        language: 'All',
        framework: 'All',
        image: 'images/5.jfif'
    }
]

const staff = Professors(professorsList);
nextProfessor();

function nextProfessor() {
    const currentProfessor = staff.next().value;
    let image = document.getElementById('image');
    let profile = document.getElementById('bio');
    // usage of ! operator of 5%

    if (currentProfessor != null) {
        image.innerHTML = `<img src='${currentProfessor.image}'>`;
        profile.innerHTML = `
        <ul>
        <li>Name: ${currentProfessor.name}</li>
        <li>Age: ${currentProfessor.age} </li>
        <li>Lives in: ${currentProfessor.city}</li>
        <li>Languages Known: ${currentProfessor.language}</li>
        <li>Framework: ${currentProfessor.framework} framework</li>
    </ul>
    `;
    }
    else {
        alert('End of our Staff List');
        
    }

}







