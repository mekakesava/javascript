let addButton = document.getElementById("addBtn");
addButton.addEventListener("click", function(e) {
  let addNotesTxt = document.getElementById("addNotesTxt");
  let notes = localStorage.getItem("notes");
  if (addNotesTxt.value == '') {
        alert('Pleaase enter notes to save');
      } else {
        notesArray = JSON.parse(notes);
        // console.log(notesArrayect);
        notesArray.push(addNotesTxt.value);
        localStorage.setItem("notes", JSON.stringify(notesArray));
        
        addNotesTxt.value = "";
      }
    
      displayNotes();
    });

// Function to show items from localStorage
function displayNotes() {
  let notes = localStorage.getItem("notes");
  if (notes == null) {
    notesObject = [];
  } else {
    notesObject = JSON.parse(notes);
  }
  let html = "";
  // usage of this of 5%
  notesObject.forEach(function(item, Sno) {
    html += `
            <div class="noteCard my-2 mx-2 card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">Note ${Sno + 1}</h5>
                        <p class="card-text"> ${item}</p>
                        <button id="${Sno}"onclick="deleteNote(this.id)"">Delete </button>
                    </div>
                </div>`;
  });
  let notesItem = document.getElementById("notes");
  if (notesObject.length != 0) {
    notesItem.innerHTML = html;
  } else {
    notesItem.innerHTML = `No Saved Notes`;
  }
}

function deleteNote(Sno) {


  let notes = localStorage.getItem("notes");
  if (notes == null) {
    notesObject = [];
  } else {
    notesObject = JSON.parse(notes);
  }

  notesObject.splice(Sno, 1);
  localStorage.setItem("notes", JSON.stringify(notesObject));
  displayNotes();
}











