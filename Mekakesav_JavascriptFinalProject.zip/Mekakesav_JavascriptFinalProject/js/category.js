

// usage of switch statement with 3 cases of 10%

function check(){
    var field = document.getElementById('category').value;
    var text;

    switch(field){
        case "student":
            text = 'Student is a valid user you can Register';
            break;

        case 'professor':
            text= 'Professor is a valid user you can Register';
            break;
        case 'staff':
            text = 'Staff is a valid user you can Register';
            break;
            default: 
            text = 'Not a valid user';
    }
    document.getElementById('message').innerHTML = text;
    
  
}
