

// Form validations weightage of 10% 

const name = document.getElementById('name');
const email = document.getElementById('email');
const phone = document.getElementById('phone');
let validEmail = false;
let validPhone = false;
let validUser = false;

// jquery methods of 15%

$('#failure').hide(); 

$('#success').hide();

name.addEventListener('blur', ()=>{
    
   
    let validation = /^[a-zA-Z]([0-9a-zA-Z]){5,8}$/;
    let input = name.value;
    if(validation.test(input)){
        name.classList.remove('is-invalid');
        validUser = true;
    }
    else{
        name.classList.add('is-invalid');
         validUser = false;
        
    }
})
phone.addEventListener('blur', function(){
    
   
    let validation = /^([0-9]){10}$/;
    let input = phone.value;
   
    if(validation.test(input)){
        
        phone.classList.remove('is-invalid');
        validPhone = true;
    }
    else{
        
        phone.classList.add('is-invalid');
        validPhone = false;
        
    }
})

email.addEventListener('blur', function(){
    
    let validation = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,9}$/;
    let input = email.value;

//    usage of if else statement of 5%

    if(validation.test(input)){
        
        email.classList.remove('is-invalid');
        validEmail = true;
    }
    else{
     
        email.classList.add('is-invalid');
        validEmail = false;
    }
})



let submit = document.getElementById('submit');
submit.addEventListener('click', function(e){
    e.preventDefault();


    
    // usage of conditional operators 5%
    if(validEmail && validUser && validPhone){
        let failure = document.getElementById('failure');

        
        let success = document.getElementById('success');
        success.classList.add('show');
    //usage of jquery methods 15%
        $('#failure').hide();
        $('#success').show();
        
    }
    else{
        let failure = document.getElementById('failure');
        failure.classList.add('show');
       
        $('#success').hide();
        $('#failure').show();
        }

    
    
})
